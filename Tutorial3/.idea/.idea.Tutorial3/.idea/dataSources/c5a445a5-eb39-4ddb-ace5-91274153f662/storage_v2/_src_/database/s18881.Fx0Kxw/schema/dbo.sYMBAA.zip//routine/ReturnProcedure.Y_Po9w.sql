CREATE PROCEDURE ReturnProcedure (@TaskName varchar(50)) AS
	BEGIN
	DECLARE @NumberOfGarages integer;
	DECLARE @GarageLocation varchar(20);
	DECLARE @GarageArea varchar(20);
	DECLARE Selecter CURSOR FOR
		SELECT Garage.Location, Garage.Area FROM Task, Garage_Task, Garage
		WHERE Task.IdTask = Garage_Task.IdTask AND Garage.IdGarage = Garage_Task.IdGarage AND Task.Name LIKE @TaskName;
	OPEN Selecter  
		FETCH NEXT FROM Selecter INTO @GarageLocation, @GarageArea
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			PRINT 'Garage Located On ' + @GarageLocation + ', With Area: {' + @GarageArea + '}.';
			FETCH NEXT FROM Selecter INTO @GarageLocation, @GarageArea
		END
	CLOSE Selecter  
	DEALLOCATE Selecter 
	SELECT @NumberOfGarages = count(Garage.IdGarage) FROM Task, Garage_Task, Garage
	WHERE Task.IdTask = Garage_Task.IdTask AND Garage.IdGarage = Garage_Task.IdGarage AND Task.Name LIKE @TaskName;
	RETURN @NumberOfGarages;
	END
go

