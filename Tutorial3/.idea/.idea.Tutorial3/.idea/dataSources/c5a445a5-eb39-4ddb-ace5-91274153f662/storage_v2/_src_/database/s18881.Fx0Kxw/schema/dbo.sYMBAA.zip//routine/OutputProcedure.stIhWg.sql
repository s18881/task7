CREATE PROCEDURE OutputProcedure (@Manager integer, @SalaryBonus integer, @NewSalary integer output) AS
	BEGIN
	DECLARE @Engineers integer;
	DECLARE Selecter CURSOR FOR
		SELECT IdEngineer FROM Engineer WHERE IdManager = @Manager;
	OPEN Selecter  
		FETCH NEXT FROM Selecter INTO @Engineers 
		WHILE @@FETCH_STATUS = 0  
		BEGIN
			UPDATE Engineer SET Salary += @SalaryBonus WHERE IdEngineer= @Engineers;
			PRINT @Engineers;
			FETCH NEXT FROM Selecter INTO @Engineers 
		END 
	CLOSE Selecter  
	DEALLOCATE Selecter  
	SELECT @NewSalary = SUM(Salary) FROM Engineer;
	END;
go

